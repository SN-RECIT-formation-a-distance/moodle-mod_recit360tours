<?php
$string['pluginname'] = 'RÉCIT 360 tour';
$string['privacy:metadata'] = 'This plugin does not store any personal data.';
$string['userpreferences'] = "User settings";
$string['recit360tours:addinstance'] = "Add instance";
$string['recit360tours:view'] = "View";
$string['modulename'] = 'RÉCIT 360 tour';
$string['modulenameplural'] = "RÉCIT 360 tour";
$string['modulename_help'] = "RÉCIT 360 tour";
$string['pluginadministration'] = "RÉCIT 360 tour module administration";
$string['maxgrade'] = 'Maximum grade';

$string['completionobjects'] = 'Require object click';
$string['completionobjects_desc'] = 'Student must click all objects marked as completion to complete this activity.';