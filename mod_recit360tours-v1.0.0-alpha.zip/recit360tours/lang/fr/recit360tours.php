<?php
$string['pluginname'] = 'Activité RÉCIT image 360';
$string['privacy:metadata'] = 'Ce plugin ne conserve aucune donnée personelle.';
$string['userpreferences'] = "Préférences de l'utilisateur";
$string['recit360tours:addinstance'] = "Ajouter une instance";
$string['recit360tours:view'] = "Vue";
$string['modulename'] = 'Activité RÉCIT image 360';
$string['modulenameplural'] = "Activité RÉCIT image 360";
$string['modulename_help'] = "Activité RÉCIT image 360";
$string['pluginadministration'] = "Activité RÉCIT image 360 module administration";

$string['maxgrade'] = 'Note totale de cet activité';

$string['completionobjects'] = 'Obligé le clique des objets';
$string['completionobjects_desc'] = 'Les élèves doivent cliquer sur tous les objets designé comme completion pour completer cette activité.';