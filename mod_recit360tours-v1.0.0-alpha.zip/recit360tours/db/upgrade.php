<?php


defined('MOODLE_INTERNAL') || die;

function xmldb_recit360tours_upgrade($oldversion) {
    global $CFG, $DB;
   
    return true;
}
